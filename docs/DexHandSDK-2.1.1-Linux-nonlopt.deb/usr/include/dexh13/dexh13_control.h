/**
 ******************************************************************************
 * @file: dexh13_control.h
 * @brief: 此文件包含 DexH13Control 类的声明。
 * @version: 1.1.0
 * @date: 2025-01-24
 * @copyright: 版权所有 (c) 2025 Paxini Robotics
 * @author: Paxini Robotics 团队
 * @details: DexH13Control 类提供了一组与 DexH13
 *灵巧手及其相机交互的方法。它包括连接和断开手部、设置关节位置、查询传感器数据、处理故障和处理相机图像的功能。
 ******************************************************************************
 */
#ifndef DEXH13_CONTROL_SDK_H
#define DEXH13_CONTROL_SDK_H

#include <iostream>
#include <memory>
#include <opencv2/opencv.hpp>
#include <string>
#include <vector>

#include "dexh13_define.h"
namespace paxini::bot::dexh13 {
class SDK_API DexH13Control {
 public:
  DexH13Control();
  virtual ~DexH13Control();

  /**
   * @brief 扫描对应协议中的设备列表
   * @param protocol_type: 协议类型，当前接口仅支持 PROTOCOL_ETHERCAT 类型。
   * @param param: protocol_type 类型为 PROTOCOL_ETHERCAT 时需要传入网络适配器名。
   * @return 返回扫描的通讯地址集。
   */
  std::vector<uint16_t> scanDevice(const CommunicationProtocol protocol_type, const std::string& param);

  /**
   * @brief 激活灵巧手和相机连接。（单手模式）
   * @param handy_port_num: 灵巧手串口编号。
   * @param camera_port_num: 相机串口编号（默认为 "none" 不使用相机）。
   * @return 成功连接，返回连接的是 LEFT_HAND=1 或 RIGHT_HAND=2。失败报错并扔出错误，中止程序
   */
  int activeHandy(const std::string& handy_port_num, const std::string& camera_port_num = "none");

  /**
   * @brief 通过 ethercat 协议连接灵巧手
   * @param addr: 连接的设备地址。
   * @param port_name: 网络适配器名。
   * @param camera_port_num: 相机串口编号（默认为 "none" 不使用相机）。
   * @return 成功连接，返回连接的是 LEFT_HAND=1 或 RIGHT_HAND=2。失败报错并扔出错误，中止程序
   */
  int connectHandByEthercat(uint16_t addr, const std::string& port_name, const std::string& camera_port_num = "none");

  /**
   * @brief 断开灵巧手连接。
   * @return 成功断开返回 1，失败返回 0。
   */
  int disconnectHandy();

  /**
   * @brief 检查灵巧手连接状态。
   * @return 已连接返回 true，未连接返回 false。
   */
  bool isConnectHandy();

  /**
   * @brief 定义电机控制模式，默认是位置模式。
   * @param mode: 电机的控制模式，可以是力矩模式、速度模式、位置模式
   * @return 设置成功返回 true，失败返回 false。
   */
  bool setMotorControlMode(const ControlMode mode);

  /**
   * @brief 定义电机最大电流，默认是 500 mA。
   * @param max_current: 范围 [0,500] 单位 mA，例如：max_current=300，实际代表300mA
   * @return 设置成功返回 true，失败返回 false。
   */
  bool setMotorMaxCurrent(int max_current);

  /**
   * @brief 定义电机最大速度，默认是 24000 rpm。
   * @param max_speed: 范围 [0,24000], 单位 rpm，例如：max_speed=2000，实际代表2000rpm
   * @return 设置成功返回 true，失败返回 false。
   */
  bool setMotorMaxSpeed(int max_speed);

  /**
   * @brief 控制电机使能。
   * @return 返回电机使能 true 或 false。
   */
  bool enableMotor();

  /**
   * @brief 控制电机下使能。
   * @return 返回电机下使能是否成功 true 或 false。
   */
  bool disableMotor();

  /**
   * @brief 查询手指电机使能状态。
   * @return 返回电机使能状态 true 或 false。
   */
  bool isMotorEnabled();

  /**
   * @brief 控制手指关节角度。
   * @param joint_angles: 手指关节数组，包含 4 个手指顺序为：食指 indexFinger，中指 middleFinger，环指（无名指）
   * ringFinger，大拇指 thumb； 每个手指（含 4 个关节）的关节名和限位空间： joint1 [-20°,
   * +20°]（掌指双轴关节-侧位摆动范围） joint2 [0°, 90°] (掌指双轴关节-弯曲伸展范围) joint3 [0°, 90°]
   * (近端关节-弯曲伸展范围) joint4 [0°, 90°] (末端关节-弯曲伸展范围)
   * @return 设置成功返回 1，失败返回 0
   */
  int setJointPositionsAngle(const std::vector<FingerAngle>& joint_angles);

  /**
   * @brief 控制手指关节弧度。
   * @param serial_rad: 包含 16 个关节弧度顺序为：
   * index_joint1, index_joint2, index_joint3, index_joint4,
   * middle_joint1, middle_joint2, middle_joint3, middle_joint4,
   * ring_joint1, ring_joint2, ring_joint3, ring_joint4,
   * thumb_joint1, thumb_joint2, thumb_joint3, thumb_joint4
   *
   * 每个关节的关节名和限位空间：
   * joint1 [Pi/180° * -20°, Pi/180° * 20°]（掌指双轴关节-侧位摆动范围）
   * joint2 [0, Pi/180° * 90°] (掌指双轴关节-弯曲伸展范围)
   * joint3 [0, Pi/180° * 90°] (近端关节-弯曲伸展范围)
   * joint4 [0, Pi/180° * 90°] (末端关节-弯曲伸展范围)
   * 住解：弧度公式：Pi/180° * 角度
   * @return 设置成功返回 1，失败返回 0
   */
  int setJointPositionsRadian(const std::vector<double>& serial_rad);

  /**
   * @brief 设置电机目标电流，在力矩模式下使用时，可以加大手的握力
   * @param target_current: 电机目标电流，包含 13 个电机目标电流，单位 mA
   * 目标电流范围：[-400, 400]
   * 注意：峰值不能长时间使用，电机过热会停止，一般使用时范围[-200, 200]
   * @return 设置成功返回 1，失败返回 0
   */
  int setMotorTargetCurrent(const Dex13MotorCurrent& target_current);

  /**
   * @brief 获取电机实际电流
   * @param actual_current: 电机实际电流，包含 13 个电机目标电流，单位 mA
   * 实际电流范围：[-400, 400]
   * @return 设置成功返回 1，失败返回 0
   */
  int getMotorActualCurrent(Dex13MotorCurrent& actual_current);

  /**
   * @brief 设置电机目标速度，在速度模式下使用时，可以控制手的运动速度
   * @param target_speed: 电机目标速度，包含 13 个电机目标速度，单位 rpm
   * 实际速度范围：[-24000, 24000]
   * @return 设置成功返回 1，失败返回 0
   */
  int setMotorTargetSpeed(const Dex13MotorSpeed& target_speed);

  /**
   * @brief 获取电机实际速度
   * @param actual_speed: 电机实际速度，包含 13 个电机实际速度，单位 rpm
   * 目标速度范围：[-24000, 24000]
   * @return 设置成功返回 1，失败返回 0
   */
  int getMotorActualSpeed(Dex13MotorSpeed& actual_speed);

  /**
   * @brief 标定灵巧手触觉传感器（校准操作）。
   * @return 返回校准状态 true 或 false。
   */
  bool calibrateSensor();

  /**
   * @brief 获取手指关节角度
   * @param joint_angles: 手指关节数组，包含 4 个手指顺序为：食指关节 indexFinger，中指关节
   * middleFinger，环指（无名指）关节 ringFinger，大拇指关节 thumb 每个手指（含 4 个关节）的关节名和限位空间： joint1
   * [-20°, +20°]（掌指双轴关节-侧位摆动范围） joint2 [0°, 90°] (掌指双轴关节-弯曲伸展范围) joint3 [0°, 90°]
   * (近端关节-弯曲伸展范围) joint4 [0°, 90°] (末端关节-弯曲伸展范围)
   */
  void getJointPositionsAngle(std::vector<FingerAngle>& joint_angles);

  /**
   * @brief 获取手指关节弧度
   * @param serial_rad: 包含 16 个关节弧度顺序为：
   * index_joint1, index_joint2, index_joint3, index_joint4,
   * middle_joint1, middle_joint2, middle_joint3, middle_joint4,
   * ring_joint1, ring_joint2, ring_joint3, ring_joint4,
   * thumb_joint1, thumb_joint2, thumb_joint3, thumb_joint4
   *
   * 每个关节的关节名和限位空间：
   * joint1 [Pi/180° * -20°, Pi/180° * 20°]（掌指双轴关节-侧位摆动范围）
   * joint2 [0, Pi/180° * 90°] (掌指双轴关节-弯曲伸展范围)
   * joint3 [0, Pi/180° * 90°] (近端关节-弯曲伸展范围)
   * joint4 [0, Pi/180° * 90°] (末端关节-弯曲伸展范围)
   */
  void getJointPositionsRadian(std::vector<double>& serial_rad);

  // 查询控制模式
  /**
   * @brief 获取电机控制模式
   * @return 返回电机控制模式
   * ControlMode::NONE = 0 无效值（只在获取模式失败时会发生无效值）
   * ControlMode::TORQUE_MODE = 1 力矩控制模式
   * ControlMode::SPEED_MODE = 2 速度控制模式
   * ControlMode::POSITION_MODE = 3 位置控制模式
   */
  ControlMode getMotorControlMode();

  /**
   * @brief 获取手指触觉传感器信息，手有 11 个传感器，总共 11 个合力，每个传感器只有一个合力信息，合力包含 3
   * 个数据，分别是 x、y、z。单位：0.1N
   * @return 返回手指触觉传感器信息
   * ForcePoint: 手指触觉传感器信息，内部包含 3 个数据分别是
   * x: 传感器x轴数据
   * y: 传感器y轴数据
   * z: 传感器z轴数据
   */
  std::vector<ForcePoint> getFingerTactile();

  /**
   * @brief 获取手指触觉传感器详细信息，手有 11 个传感器，总共 1140 分布力，分布力包含 3 个数据，分别是 x、y、z
   * 其中食指中部，中指中部，环指（无名指）中部的关节上触觉传感器有60个分布力，其余关节的触觉传感器有 120
   * 个分布力。单位：0.1N
   * @return  返回手指触觉传感器的详细阵列力信息
   * ForcePoint: 手指触觉传感器信息，内部包含 3 个数据分别是
   * x: 传感器x轴数据
   * y: 传感器y轴数据
   * z: 传感器z轴数据
   */
  std::vector<ForcePoint> getFingerTactileDetail();

  /**
   * @brief 获取手指传感器温度数据，手有 11 个传感器，总共 11 个温度数据。单位：1℃
   * @return 返回手指传感器温度数据
   * FingerTemp: 传感器温度数据结构内部包含
   * std::string finger_name 手指名称
   * int sensor_ID 传感器 ID
   * float temperature 传感器温度数据
   */
  std::vector<FingerTemp> getTemperature();

  /**
   * @brief 获取全部数据（包括合力、阵列力和温度）
   * @param finger_tac: 手指触觉传感器合力信息
   * @param finger_tac_detail: 手指触觉传感器分布力信息
   * @param temperature: 手指传感器温度数据
   */
  void getAllTactileData(std::vector<ForcePoint>& finger_tac, std::vector<ForcePoint>& finger_tac_detail,
                         std::vector<FingerTemp>& temperature);

  /**
   * @brief: 手指故障状态 - 查询是否发生故障
   * @return true 表示发生故障，false 表示未发生故障
   */
  bool isFault();

  /**
   * @brief 获取电机故障码，了解当前电机故障原因
   * @return 返回电机故障码
   */
  std::vector<FingerMotorsError> getFaultCode();

  /**
   * @brief 清除电机故障码
   * @return 返回清除结果 true 表示清除成功，false 表示清除失败
   */
  bool clearFaultCode();

  /**
   * @brief 获取当前帧功能。
   * @return 返回一帧图像默认像素尺寸是640x720，如果相机未打开则返回空Mat
   */
  cv::Mat getFrame();

  /**
   * @brief 显示一帧图片
   * @param ImgName 图片名称
   * @param Img 图片
   */
  void showImage(const std::string& ImgName, const cv::Mat& Img);

  /**
   * @brief 保存一帧图片
   * @param imgPath 图片路径
   * @param img 图片
   */
  void saveImage(const std::string& imgPath, const cv::Mat& img);

  /**
   * @brief 设置相机分辨率和帧率
   * @param width 分辨率宽度
   * @param height 分辨率相机高度
   * @param fps 相机帧率
   * @return 设置成功返回 true，失败返回 false
   */
  bool setCameraConfig(int width, int height, float fps);

  /**
   * @brief 图像校正（去畸变）
   * @param distortedFrame 畸变的图像
   * @param cameraMatrix 相机内参矩阵
   * @param distCoeffs 相机畸变系数
   * @return 去畸变的图像
   */
  cv::Mat undistortImage(const cv::Mat& distortedFrame, const cv::Mat& cameraMatrix, const cv::Mat& distCoeffs);

  /**
   * @brief 获取相机内参矩阵和畸变系数
   * @param width 相机宽度
   * @param height 相机高度
   * @return 返回相机内参矩阵和畸变系数
   */
  std::pair<cv::Mat, cv::Mat> getIntrinsicMatrixAndDistCoeffs(int width, int height);

  /**
   * @brief 获取相机外参矩阵
   * @return 返回相机外参矩阵
   */
  cv::Mat getHandEyeMatrix();

  /**
   * @brief 版本信息。
   * @return 返回固件版本信息。
   */
  const std::string getFirmwareVersion();
  /**
   * @brief 版本信息。
   * @return SDK 版本信息。
   */
  const std::string getSDKVersion();

  /**
   * @brief: 初始化电机位置，用于初始化电机位置，回到初始位置
   * 建议在刚上电时调用，最大耗时约：5s
   * @return 返回 1 是成功，返回 0 是失败
   */
  int initMotorPosition();

  /**
   * @brief: 使用电机参数设置电机位置
   * @return 返回 1 是成功，返回 0 是失败
   */
  int setMotorTargetPosition(const Dex13MotorPosition& target_position);

  /**
   * @brief 获取电机位置信息
   * @return 电机位置信息
   */
  const Dex13MotorPosition getMotorPosition();

  /**
   * @brief: 升级主控固件版本，准备升级前请重新上电
   * @param file_names：主控板固件文件名列表，必须包含 CM7 和 CM4 的固件文件,升级文件需要和程序同目录
   * @return: 返回错误码，含义见 UpgradeErrorCode 注释
   */
  UpgradeErrorCode upgradeMainboard(const std::vector<std::string>& file_names);

  /**
   * @brief: 升级电驱板固件版本，准备升级前请重新上电
   * @param info：电驱板固件与升级部位列表，电驱板固件升级文件需要和程序同目录，升级部位分别为：
   *                 食指双驱（0x0201）、食指单驱（0x0101）、中指双驱（0x0202）
   *                 中指单驱（0x0102）、无名指双驱（0x0203）、无名指单驱（0x0103）
   *                 侧摆双驱（0x0204）、拇指单驱（0x0104）、拇指尖单驱（0x0105）
   *
   * @return 返回错误码，含义见 UpgradeErrorCode 注释
   */
  UpgradeErrorCode upgradeDriveboard(const std::vector<UpgradeFileAndPart>& info);

  /**
   * @brief: 获取升级进度信息
   * @details: 获取传入的部位的固件升级信息
   * 如需使用，请在固件对应的固件升级接口（upgradeMainboard 或 upgradeMainboard）前开启单独的线程调用
   *
   * @return 对应类型的固件升级状态集合
   */
  const std::vector<UpgradeProcess> getUpgradeInfo();

  /**
   * @brief: 获取按压力集。单位：0.1N
   * @return：返回按压力点集
   */
  std::vector<PressForcePoint> getPressPositionForce();

 private:
  std::unique_ptr<DexH13ControlImpl> impl_;
};

}  // namespace paxini::bot::dexh13
#endif  // DEXH13_CONTROL_SDK_H
