#ifndef DEXH13_KINEMATIC_H
#define DEXH13_KINEMATIC_H

#include "dexh13_define.h"

namespace paxini::bot::dexh13 {

class SDK_API DexH13Kinematic {
 public:
  DexH13Kinematic();
  ~DexH13Kinematic();

  /**
   * @brief 版本信息。
   * @return SDK 版本信息。
   */
  const std::string getSDKVersion();

  /**
   * @brief 逆运动学接解析，通过弧度值获取电机值
   * @param hand_type 左手或者右手
   * @param serial_rad 弧度集，必须包含 16 个元素
   * @param motor_pos 运动学解析得到的 13 个电机位置信息
   * @return 成功返回 1，失败返回 0
   */
  int inverseKinematicParse(const HandType hand_type, const std::vector<double>& serial_rad,
                            std::vector<int16_t>& motor_pos);
  /**
   * @brief 正运动学，通过电机值获取弧度值
   * @param hand_type 左手或者右手
   * @param motor_pos 13 个电机位置值集合
   * @param serial_rad 运动学解析得到的弧度信息集
   * @return 成功返回 1，失败返回 0
   */
  int forwardKinematicParse(const HandType hand_type, const std::vector<int16_t>& motor_pos,
                            std::vector<double>& serial_pos);

 private:
  std::unique_ptr<DexH13KinematicImpl> impl_;

};  // end of class DexH13Kinematic

}  // end of namespace paxini::bot::dexh13
#endif