/**
 * @file: dexh13_define.h
 * @brief: This file contains the definitions and declarations for DexH13 control.
 * @version: 1.1.0
 */

#ifndef DEXH13_DEFINE_H
#define DEXH13_DEFINE_H

#include <atomic>
#include <functional>
#include <iostream>
#include <memory>
#include <set>
#include <string>

#ifdef _WIN32
// 设置导出标志
#ifdef WIN_SDK_EXPORTS
#define SDK_API __declspec(dllexport)
#else
#define SDK_API __declspec(dllimport)
#endif

#elif __linux__
// 设置默认打开的串口名
#define SDK_API

#endif

namespace paxini::bot::dexh13 {

// 激活灵巧手的定义 none:0 left:1, right:2
enum HandType {
  NONE_HAND = 0,
  LEFT_HAND = 1,
  RIGHT_HAND = 2,
};

/**
 * 电机控制模式 DexH13 Motor Control Mode
 * 0: 无效值（只在获取模式失败时会发生无效值）
 * 1: 力矩控制模式
 * 2: 速度控制模式
 * 3: 位置控制模式
 */
enum ControlMode {
  NONE = 0,
  TORQUE_CONTROL_MODE = 1,
  SPEED_CONTROL_MODE = 2,
  POSITION_CONTROL_MODE = 3,
};

// 手指电机故障码 DexH13，枚举类 ErrorCode，用于表示不同的错误代码
enum class ErrorCode {
  OVER_VOLT = 0,
  UNDER_VOLT = 1,
  OVER_CURRENTU = 2,
  OVER_CURRENTV = 3,
  OVER_CURRENTW = 4,
  OVER_TEMPERATURE = 5,
  ADC_CALIB = 6,
  FOC_ERR = 7,
  OVER_IQ = 8,
  OPD_U = 9,
  OPD_V = 10,
  OPD_W = 11,
  POS_REF_OVER = 12,
  POS_REF_UNDER = 13,
  ABZ_ERR = 14,
  ABZ_Z_ERR = 15,
  RESERVED0 = 16,
  RESERVED1 = 17,
  RESERVED2 = 18,
  RESERVED3 = 19,
  RESERVED4 = 20,
  RESERVED5 = 21,
  RESERVED6 = 22,
  RESERVED7 = 23,
  RESERVED8 = 24,
  RESERVED9 = 25,
  RESERVED10 = 26,
  RESERVED11 = 27,
  RESERVED12 = 28,
  RESERVED13 = 29,
  RESERVED14 = 30,
  DISCONNECT = 31,
};

/* 速度 */
struct Dex13MotorSpeed {
  int16_t motor1_speed;
  int16_t motor2_speed;
  int16_t motor3_speed;
  int16_t motor4_speed;
  int16_t motor5_speed;
  int16_t motor6_speed;
  int16_t motor7_speed;
  int16_t motor8_speed;
  int16_t motor9_speed;
  int16_t motor10_speed;
  int16_t motor11_speed;
  int16_t motor12_speed;
  int16_t motor13_speed;
};

/* 电流 */
struct Dex13MotorCurrent {
  int16_t motor1_current;
  int16_t motor2_current;
  int16_t motor3_current;
  int16_t motor4_current;
  int16_t motor5_current;
  int16_t motor6_current;
  int16_t motor7_current;
  int16_t motor8_current;
  int16_t motor9_current;
  int16_t motor10_current;
  int16_t motor11_current;
  int16_t motor12_current;
  int16_t motor13_current;
};

// 手指电机错误码结构体：手指名称，电机ID，故障码对应关系的建立
// 手指名称有13：LeftThumb、LeftIndex、LeftMiddle、LeftRing、LeftPinky、RightThumb、RightIndex、RightMiddle、RightRing、RightPinky
// 电机有ID有：1、2、3、4、5、6、7、8、9、10、11、12、13
// 查看手指电机故障码 DexH13 Finger Motor Fault Code
struct FingerMotorsError {
  std::string finger_name;  // 手指名称
  int motor_ID;             // 手指电机ID
  ErrorCode error_code;     // 手指电机故障码
};

struct FingerTemp {
  std::string finger_name;  // 手指名称
  int sensor_ID;            // 传感器ID
  float temperature;        // 手指温度（手指上的传感器）
};

// 触觉传感器信息，包含三个维度的力： x, y, z
struct ForcePoint {
  int x;  // x轴方向的力
  int y;  // y轴方向的力
  int z;  // z轴方向的力
};

// FingerAngle 手指角度控制，Dexh13 灵巧手指的包括（食指 中指，环指，大拇指）
struct FingerAngle {
  double joint1;  // 关节 1 侧摆角度（掌指双轴关节）
  double joint2;  // 关节 2 曲伸角度（掌指双轴关节）
  double joint3;  // 关节 3 曲伸角度（近端关节）
  double joint4;  // 关节 4 曲伸角度（末端关节）
};

struct Dex13MotorPosition {
  /* 位置 */
  int16_t motor1_pos;
  int16_t motor2_pos;
  int16_t motor3_pos;
  int16_t motor4_pos;
  int16_t motor5_pos;
  int16_t motor6_pos;
  int16_t motor7_pos;
  int16_t motor8_pos;
  int16_t motor9_pos;
  int16_t motor10_pos;
  int16_t motor11_pos;
  int16_t motor12_pos;
  int16_t motor13_pos;
  Dex13MotorPosition()
      : motor1_pos(0),
        motor2_pos(0),
        motor3_pos(0),
        motor4_pos(0),
        motor5_pos(0),
        motor6_pos(0),
        motor7_pos(0),
        motor8_pos(0),
        motor9_pos(0),
        motor10_pos(0),
        motor11_pos(0),
        motor12_pos(0),
        motor13_pos(0){};
};

enum MotorType {
  INVALID_MOTOR_TYPE = 0,
  MOTOR_TYPE_1 = 1,
  MOTOR_TYPE_2 = 2,
};

// 固件升级类型
enum FirmwareUpgradeType {
  INVALID_UPGRADE = 0,    // 无效的升级类型
  MAINBOARD_UPGRADE = 1,  // 主控板升级
  DRIVER_UPGRADE = 2,     // 电驱板升级
  SENSOR_UPGRADE = 3,     // 传感器升级
};

// 固件升级错误码
enum class UpgradeErrorCode : int {
  UPGRADE_CHECK_OK = 1001,  // 升级检查正常
  UPGRADE_FAIL = 1002,      // 升级失败
  UPGRADE_SUCCESS = 1003,   // 升级成功

  FILE_FORMAT_ERROR = 2001,   // 文件格式异常
  FILE_SIZE_ERROR = 2002,     // 文件大小异常
  FILE_MATCH_ERROR = 2003,    // 文件匹配异常
  FILE_NAME_ERROR = 2004,     // 文件名异常
  FILE_COUNT_ERROR = 2005,    // 文件数量异常
  FILE_EXIT_ERROR = 2006,     // 文件不存在
  FILE_VERSION_ERROR = 2007,  // 文件版本错误

  PARAM_PART_ERROR = 3001,  // 部位参数错误

  HAND_FAULT_ERROR = 4001,   // 设备故障错误
  HAND_ENABLE_ERROR = 4002,  // 设备使能错误

  SEND_FILE_OPERATE_ERROR = 5001,  // 文件操作异常
  SEND_FRAME_1_ERROR = 5002,       // 首帧发送失败
  SEND_FRAME_N_ERROR = 5003,       // 中间帧发送失败
  SEND_FRAME_LAST_ERROR = 5004,    // 最后帧发送失败
  SEND_EXTRA_ACTION_ERROR = 5005,  // 确认动作失败
  FILE_SEND_SUCCESS = 5006,        // 文件发送成功
  UPGRADE_REQUEST_ERROR = 5007,    // 请求升级指令失败
  UPGRADE_EXECUTE_ERROR = 5008,    // 升级指令执行失败
  UPGRADE_TYPE_ERROR = 5009,       // 升级类型错误
};

// 升级的固件列表信息
struct UpgradeFileAndPart {
  std::string file_path;
  std::set<int16_t> upgrade_part;
};

// 固件文件属性
struct FirewareFields {
  FirmwareUpgradeType upgrade_type;  // 升级类型
  std::string upgrade_version;       // 升级版本（电驱板类型时为序列号）
  std::string reserve1;              // 保留字段1
  std::string reserve2;              // 保留字段2
  std::string reserve3;              // 保留字段3
};

// 固件升级信息
struct UpgradeInfo {
  std::string file_path;
  FirewareFields file_fields;
  std::set<int16_t> upgrade_part;
};

// 固件升级进度信息
struct UpgradeProcess {
  FirmwareUpgradeType upgrade_type;  // 升级类型
  int16_t part;                      // 升级的固件
  int process_data;                  // 升级进度值，范围为：[0, 100]
  std::string status;                // 升级状态说明

  UpgradeProcess() : upgrade_type(INVALID_UPGRADE), part(0), process_data(0), status("") {}
};

struct MotorVersion {
  int16_t part;           // 电驱板部位
  std::string version;    // 版本
  std::string part_name;  // 电驱板部位名字
};

struct SensorSequence {
  int16_t part;           // 传感器模块
  std::string sequence;   // 序列号
  std::string part_name;  // 传感器模块名
};

struct SensorVersion {
  int16_t part;           // 传感器模块
  std::string version;    // 版本
  std::string part_name;  // 传感器模块名
};

// 传感器按压位置力
struct PressForcePoint {
  int x;                   // x坐标
  int y;                   // y坐标
  int z;                   // z坐标
  uint32_t force_value;    // 触点的力
  std::string model_name;  // 触点所在模组
};

// 协议类型
enum CommunicationProtocol {
  INVALID_PROTOCOL = 0,
  PROTOCOL_RS485 = 1,
  PROTOCOL_ETHERCAT = 2,
};

/*
 * @brief 力控参数配置
 * @details 成员的集合长度均为
 * 8，依次为：食指近端口关节、食指远端关节、中指近端、中指远端、环指（无名指）近端、环指（无名指）远端、拇指近端、拇指远端
 */
struct ForceCtlParam {
  std::vector<double> impedance_factor;        // 阻抗因子参数，单个关节的值范围为 [1, 100]
  std::vector<double> reference_force_factor;  // 参考力系数参数，单个关节的值范围为 [1, 10]
  std::vector<bool> enable_flag;               // 力控是否生效的关节标记，默认开启所有关节（8个）
};

// 文件处理回调
using ProcessFileCallback = std::function<int(int process_percent, std::string status)>;

class DexH13ControlImpl;    // forward declaration
class DexH13KinematicImpl;  // forward declaration

}  // namespace paxini::bot::dexh13
#endif  // DEXH13_DEFINE_H
