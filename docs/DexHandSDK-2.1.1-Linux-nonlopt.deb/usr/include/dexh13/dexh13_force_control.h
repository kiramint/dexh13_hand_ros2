#ifndef DEXH13_FORCE_CONTROL_H
#define DEXH13_FORCE_CONTROL_H

#include "dexh13_define.h"

namespace paxini::bot::dexh13 {

class SDK_API DexH13ForceControl {
 public:
  DexH13ForceControl();
  ~DexH13ForceControl();

  /**
   * @brief 版本信息。
   * @return SDK 版本信息。
   */
  const std::string getSDKVersion();

  /**
   * @brief 配置力控参数
   * @param hand_type: 灵巧手左右手类型，LEFT_HAND 左手，RIGHT_HAND 右手
   * @param param: 力控效果的配置参数
   * param.impedance_factor 阻抗因子参数。配置的关节数值大速度越快，数值范围为 [1, 100]
   * param.reference_force_factor 参考力系数参数。配置的关节的数值越大，关节的受力越大，数值范围为 [1, 10]
   * param.enable_flag 力控是否生效的关节标记。默认开启所有关节（8个）
   * @detail: 成员的集合长度均为
   * 8，依次为：食指近端口关节、食指远端关节、中指近端、中指远端、环指（无名指）近端、环指（无名指）远端、拇指近端、拇指远端
   * @return 成功返回 1, 失败返回 0
   */
  int setForceCtlParam(const HandType hand_type, const ForceCtlParam& param);

  /**
   * @brief 计算下次运动的目标指令
   * @param hand_type: 灵巧手左右手类型，LEFT_HAND 左手，RIGHT_HAND 右手
   * @param cur_serial_pos_vec：灵巧手当前关节弧度值集合。集合中的数值顺序为：食指、中指、环指（无名指）、拇指
   * @param sensor_info: 当前的传感器的合力数据
   * @param command：下次运动的弧度信息
   * @return 成功返回 1, 失败返回 0
   */
  int computeSerialTargetCommand(const HandType hand_type, std::vector<double> cur_serial_pos_vec,
                                 const std::vector<ForcePoint>& sensor_info, std::vector<double>& command);

 private:
  std::unique_ptr<DexH13KinematicImpl> impl_;

};  // end of class DexH13ForceControl

}  // end of namespace paxini::bot::dexh13
#endif