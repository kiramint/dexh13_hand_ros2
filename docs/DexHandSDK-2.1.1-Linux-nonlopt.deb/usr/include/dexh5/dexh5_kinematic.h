#ifndef DEXH5_KINEMATIC_H
#define DEXH5_KINEMATIC_H

#include "dexh5_define.h"

namespace paxini::bot::dexh5 {

class SDK_API DexH5Kinematic {
 public:
  DexH5Kinematic();
  ~DexH5Kinematic();

  /**
   * @brief 版本信息。
   * @return SDK 版本信息。
   */
  const std::string getSDKVersion();

  /**
   * @brief 逆运动学解析，通过弧度值获取电机值
   * @param hand_type 左手或者右手
   * @param serial_rad 手指关节数组 5 个关节的控制顺序：
   *        - index mcp 食指弧度: (0 ~ 77.5°*PI/180)
   *        - middle mcp 中指弧度: (0 ~ 77.5°*PI/180)
   *        - ring mcp 环指弧度: (0 ~ 77.5°*PI/180)
   *        - thumb cmc 拇指掌心弧度: (0 ~ 32°*PI/180)
   *        - thumb mcp 拇指弧度: (0 ~ 43.6°*PI/180)
   * @param motor_pos 保存运动学解析得到的手指电机位置集
   * @return 成功返回 1，失败返回 0
   */
  int inverseKinematicParse(const HandType hand_type, const std::vector<double>& serial_rad,
                            std::vector<int16_t>& motor_pos);
  /**
   * @brief 正运动学解析，通过电机值获取弧度值
   * @param hand_type 左手或者右手
   * @param motor_pos 手指关节组的 5 个电机位置值集合
   * @param serial_rad 保存运动学解析得到的手指弧度集
   * @return 成功返回 1，失败返回 0
   */
  int forwardKinematicParse(const HandType hand_type, const std::vector<int16_t>& motor_pos,
                            std::vector<double>& serial_pos);

 private:
  std::unique_ptr<DexH5KinematicImpl> impl_;

};  // end of class DexH5Kinematic

}  // end of namespace paxini::bot::dexh5

#endif