/**
 ******************************************************************************
 * @file: dexh5_control.h
 * @brief: This file contains the declaration of the DexH5Control class, which is responsible for controlling the DexH5
 *robotic hand.
 * @version: 1.1.0
 * @date: 2025-03-13
 * @copyright: Copyright (c) 2025 Paxini Robotics
 * @author: Paxini Robotics Team
 * @details: The DexH5Control class provides a set of methods to interact with the DexH5 robotic hand, including
 *connecting to the hand, setting joint positions, and retrieving sensor information.
 ******************************************************************************
 */

#ifndef DEXH5_CONTROL_SDK_H
#define DEXH5_CONTROL_SDK_H

#include <iostream>
#include <memory>
#include <string>
#include <vector>

#include "dexh5_define.h"

namespace paxini::bot::dexh5 {

class SDK_API DexH5Control {
 public:
  DexH5Control();
  virtual ~DexH5Control();

  /**
   * @brief 连接灵巧手功能（单手模式）
   * @param hand_port_num 灵巧手串口编号，例如 "/dev/ttyUSB0"
   * @return 连接成功返回 HAND_TYPE (1 表示 LEFT_HAND, 2 表示 RIGHT_HAND)
   *         连接失败中止程序，报错误信息
   */
  HandType connectDevice(const std::string& hand_port_num);

  /**
   * @brief 断开灵巧手连接
   * @return 断开成功返回 1，失败返回 0
   */
  int disconnectDevice();

  /**
   * @brief 检查灵巧手连接状态
   * @return 处于连接返回 1，未连接返回 0
   */
  bool isConnected();

  /**
   * @brief 查询电机使能状态
   * @return 使能返回 true，未使能返回 false
   */
  bool isMotorEnabled();

  /**
   * @brief 自定义电机最大电流
   * @param max_current 电机最大电流，范围：600~2000 mA, 默认是 1400 mA
   * @return 设置成功返回 SUCCESS，失败返回 FAILURE。其他返回详见： dexh5_define.h 文件里 enum HReturnCode 定义
   */
  HReturnCode setMotorMaxCurrent(uint16_t max_current);

  /**
   * @brief 设置电机的维持力矩和维持时间
   * @details 用于灵巧手在抓握过程中保持一定的抓握力和维持时间，以便于在物体状态变化时进行动态调整。
   * @param min_torque 最小维持力矩，范围：150~850 mA, 默认值为 250 mA。
   * @param hold_duration 维持时间，范围：1~65535，单位秒，缺省时默认为 15 秒。
   * 注意: 长时间维持电机可能导致发热和损坏。
   * @return 设置成功返回 SUCCESS，失败返回 FAILURE。其他返回值详见 dexh5_define.h 文件中的 enum HReturnCode 定义。
   */
  HReturnCode setMotorHoldTorque(uint16_t min_torque, uint16_t hold_duration = 15);

  /**
   * @brief 控制手指关节角度，单位为角度°
   * @param joint_angles 手指关节数组 5 个关节的控制顺序：
   *        - index mcp 食指角度: (0, 77.5°)
   *        - middle mcp 中指角度: (0, 77.5°)
   *        - ring mcp 环指角度: (0, 77.5°)
   *        - thumb cmc 拇指掌心角度: (0, 48°)
   *        - thumb mcp 拇指角度: (0, 43.6°)
   * @return 设置成功返回 SUCCESS，失败返回 FAILURE。其他返回详见： dexh5_define.h 文件里 enum HReturnCode 定义
   */
  HReturnCode setJointPositionsDegree(const std::vector<double>& joint_angles);

  /**
   * @brief 控制手指关节弧度，单位为弧度，范围 0 - 1/2 * PI
   * @param joint_radians 手指关节数组 5 个关节的控制顺序：
   *        - index mcp 食指弧度: (0 to 77.5°*PI/180)
   *        - middle mcp 中指弧度: (0 to 77.5°*PI/180)
   *        - ring mcp 环指弧度: (0 to 77.5°*PI/180)
   *        - thumb cmc 拇指掌心弧度: (0 to 48°*PI/180)
   *        - thumb mcp 拇指弧度: (0 to 43.6°*PI/180)
   * @return 设置成功返回 SUCCESS，失败返回 FAILURE。其他返回详见： dexh5_define.h 文件里 enum HReturnCode 定义
   */
  HReturnCode setJointPositionsRadian(const std::vector<double>& joint_radians);

  /**
   * @brief 标定灵巧手触觉传感器（校准操作）
   * @return 校准设置成功返回 SUCCESS，失败返回 FAILURE。其他返回详见： dexh5_define.h 文件里 enum HReturnCode 定义
   */
  HReturnCode calibrateTactile();

  /**
   * @brief 获取手指关节角度位置，单位为角度°
   * @param[out] serial_ang 手指关节数组 5 个关节的顺序：
   *        - index mcp 食指角度: (0, 77.5°)
   *        - middle mcp 中指角度: (0, 77.5°)
   *        - ring mcp 环指角度: (0, 77.5°)
   *        - thumb cmc 拇指掌心角度: (0, 48°)
   *        - thumb mcp 拇指角度: (0, 43.6°)
   * @return 设置成功返回 SUCCESS，失败返回 FAILURE。其他返回详见： dexh5_define.h 文件里 enum HReturnCode 定义
   */
  HReturnCode getJointPositionsDegree(std::vector<double>& serial_ang);

  /**
   * @brief 获取手指关节弧度位置，单位为弧度 rad
   * @param[out] serial_rad 手指 5 个关节的顺序：
   *        - index mcp 食指弧度: (0 to 77.5°*PI/180)
   *        - middle mcp 中指弧度: (0 to 77.5°*PI/180)
   *        - ring mcp 环指弧度: (0 to 77.5°*PI/180)
   *        - thumb cmc 拇指掌心弧度: (0 to 48°*PI/180)
   *        - thumb mcp 拇指弧度: (0 to 43.6°*PI/180)
   * @return 设置成功返回 SUCCESS，失败返回 FAILURE。其他返回详见： dexh5_define.h 文件里 enum HReturnCode 定义
   */
  HReturnCode getJointPositionsRadian(std::vector<double>& serial_rad);

  /**
   * @brief 获取电机当前电流和温度
   * @param[out] finger_current 手指电机顺序：index食指电流、middle中指电流、
   *             ring环指电流、thumb掌心关节电机电流、thumb拇指电流
   * @param[out] finger_temp 手指关节顺序：index食指温度、middle中指温度、
   *             ring环指温度、thumb掌心关节电机温度、thumb拇指温度
   * @return 设置成功返回 SUCCESS，失败返回 FAILURE。其他返回详见： dexh5_define.h 文件里 enum HReturnCode 定义
   */
  HReturnCode getMotorCurrentAndTemperature(std::vector<int>& finger_current, std::vector<float>& finger_temp);

  /**
   * @brief 查询手指上触觉传感器三维合力和温度信息，单位为牛顿和摄氏度
   * @param[out] force_points 4个手指顺序，ring环指，middle中指，index食指，thumb拇指，每个手指含有 2 个传感器
   *             传感器顺序：无名指腹，无名指尖，中指腹，中指尖，食指腹，食指尖，拇指腹，拇指尖
   * @return 设置成功返回 SUCCESS，失败返回 FAILURE。其他返回详见： dexh5_define.h 文件里 enum HReturnCode 定义
   */
  HReturnCode getTactileResultantForce(std::vector<H5ForcePoint>& force_points);

  /**
   * @brief 查询手指上触觉传感器三维力和温度信息，以及三维分布力，单位为牛顿和摄氏度
   * @param[out] force_points 4个手指顺序，ring环指，middle中指，index食指，thumb拇指，每个手指含有 2 个传感器
   *             传感器顺序：无名指腹，无名指尖，中指腹，中指尖，食指腹，食指尖，拇指腹，拇指尖
   * @return 设置成功返回 SUCCESS，失败返回 FAILURE。其他返回详见： dexh5_define.h 文件里 enum HReturnCode 定义
   */
  HReturnCode getTactileDistributedForce(std::vector<H5ForcePoint>& force_points);

  /**
   * @brief 查询是否发生故障
   * @return 发生故障返回 true, 未发生故障返回 false
   */
  bool isFault();

  /**
   * @brief 查询当前故障状态原因
   * @param[out] fault_code 4个手指顺序，index食指故障码、middle中指故障码、ring无名指故障码、thumb拇指故障码
   * @return 设置成功返回 SUCCESS，失败返回 FAILURE。其他返回详见： dexh5_define.h 文件里 enum HReturnCode 定义
   */
  HReturnCode getFaultCode(std::vector<ErrorCode>& fault_code);

  /**
   * @brief 清除当前故障码
   * @return 清除成功返回 true，故障未清除失败返回 false
   */
  bool clearFaultCode();

  /**
   * @brief 版本信息
   * @return 返回版本信息 VersionInfo 结构体，包含 SDK版本和固件版本
   *         例如 sdk_version = "v1.1.0"，firmware version = "v1.0.0"
   */
  const VersionInfo getVersion();

  /**
   * @brief 获取手部运行状态
   * @return 返回手部运行状态：
   *         - DEVICE_DISABLED: 未使能
   *         - DEVICE_ERROR: 故障
   *         - DEVICE_RUNNING_OK: 正常
   *         - DEVICE_NOT_FOUND: 设备未找到
   */
  HReturnCode getRuntimeStatus();

  /**
   * @brief 获取电机当前位置，单位为mm
   * 食指、中指、无名指范围：- 0 to 1250 mm,最小单位：0.008 mm
   * 拇指掌心侧摆电机范围：- 0 to 1400 mm,最小单位：0.005 mm
   * 拇指弯曲电机范围：- 0 to 1700 mm,最小单位：0.005 mm
   * @param cur_position 电机位置数组
   * @return 设置结果
   */
  HReturnCode getMotorPosition(std::vector<int16_t>& cur_position);

 private:
  std::unique_ptr<DexH5ControlImpl> impl_;
};

}  // namespace paxini::bot::dexh5

#endif  // DEXH5_CONTROL_SDK_H
