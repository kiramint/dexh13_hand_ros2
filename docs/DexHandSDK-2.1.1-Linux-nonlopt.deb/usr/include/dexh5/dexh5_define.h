/**
 * @file dexh5_define.h
 * @brief This file contains the definitions and declarations required for DexH5 control.
 * @version 1.1.0
 * @date: 2025-03-13
 * @copyright: Copyright (c) 2025 Paxini Robotics
 * @author: Paxini Robotics Team
 * @details: The file defines various enumerations, structures, and a forward declaration for the implementation class
 * required to interface with and control the DexH5 robotic hand. These include types of hands, return codes for
 * operations, error codes for finger motors, data structures for tactile force points, and version information.
 */

#ifndef DEXH5_DEFINE_H
#define DEXH5_DEFINE_H

#include <iostream>
#include <memory>
#include <string>
#include <vector>

#ifdef _WIN32
// 设置导出标志
#ifdef WIN_SDK_EXPORTS
#define SDK_API __declspec(dllexport)
#else
#define SDK_API __declspec(dllimport)
#endif

#elif __linux__
// 设置导出标志
#define SDK_API

#endif

namespace paxini::bot::dexh5 {

/**
 * @enum HandType
 * @brief 激活灵巧手的类型定义
 */
enum HandType {
  UNKNOW_HAND = 0, /**< 无激活手 */
  LEFT_HAND = 1,   /**< 左手 */
  RIGHT_HAND = 2,  /**< 右手 */
};

/**
 * @enum HReturnCode
 * @brief 定义手部操作的返回码
 */
enum HReturnCode {
  FAILURE = 0,           /**< 操作失败 */
  SUCCESS = 1,           /**< 操作成功 */
  TIMEOUT = 2,           /**< 操作超时 */
  DEVICE_NOT_FOUND = 3,  /**< 未找到设备 */
  DEVICE_DISABLED = 4,   /**< 设备未使能 */
  DEVICE_ERROR = 5,      /**< 设备故障 */
  DEVICE_RUNNING_OK = 6, /**< 设备正常运行中 */
};

/**
 * @enum ErrorCode
 * @brief 手指电机故障码，表示不同的错误类型
 */
enum ErrorCode {
  INDEX_MOTOR_ERR = 0,                   /**< 食指电机错误 */
  MIDDLE_MOTOR_ERR = 1,                  /**< 中指电机错误 */
  RING_MOTOR_ERR = 2,                    /**< 无名指电机错误 */
  THUMB_CMC_MOTOR_ERR = 3,               /**< 拇指CMC电机错误 */
  THUMB_MCP_MOTOR_ERR = 4,               /**< 拇指MCP电机错误 */
  RING_DP_SENSOR_DISCONNECTED_ERR = 5,   /**< 无名指DP传感器断开错误 */
  RING_MP_SENSOR_DISCONNECTED_ERR = 6,   /**< 无名指MP传感器断开错误 */
  MIDDLE_DP_SENSOR_DISCONNECTED_ERR = 7, /**< 中指DP传感器断开错误 */
  MIDDLE_MP_SENSOR_DISCONNECTED_ERR = 8, /**< 中指MP传感器断开错误 */
  INDEX_DP_SENSOR_DISCONNECTED_ERR = 9,  /**< 食指DP传感器断开错误 */
  INDEX_MP_SENSOR_DISCONNECTED_ERR = 10, /**< 食指MP传感器断开错误 */
  THUMB_DP_SENSOR_DISCONNECTED_ERR = 11, /**< 拇指DP传感器断开错误 */
  THUMB_MP_SENSOR_DISCONNECTED_ERR = 12, /**< 拇指MP传感器断开错误 */
};

/**
 * @struct H5ForcePoint
 * @brief DexH5手指触觉力点数据结构
 * @details 包含更详细的传感器信息和力点数据
 */
struct H5ForcePoint {
  int point_id;             /**< 坐标位置 (有60和72个坐标，根据sensor_id不同而不同) */
  int x;                    /**< x轴压力值 */
  int y;                    /**< y轴压力值 */
  int z;                    /**< z轴压力值 */
  int sensor_active_points; /**< 传感器实际发生触觉力的坐标点数量 */
  int sensor_points;        /**< 传感器坐标点总数量 */
  float sensor_temperature; /**< 传感器温度值（摄氏度） */
  int sensor_id;            /**< 手指触觉传感器编号 ID (1,2,3,4,5,6,7,8) */
  std::string finger_name; /**< 所属手指名称：Thumb（拇指）、Index（食指）、Middle（中指）、Ring（无名指）*/
};

/**
 * @struct VersionInfo
 * @brief 版本信息结构体
 * @details 包含 SDK 版本和固件版本信息
 */
struct VersionInfo {
  std::string sdk_version;      /**< SDK 版本号 */
  std::string firmware_version; /**< 固件版本号 */
};

/**
 * @class DexH5ControlImpl
 * @brief DexH5控制实现类（前向声明）
 */
class DexH5ControlImpl;    // forward declaration
class DexH5KinematicImpl;  // forward declaration

}  // namespace paxini::bot::dexh5
#endif  // DEXH5_DEFINE_H
