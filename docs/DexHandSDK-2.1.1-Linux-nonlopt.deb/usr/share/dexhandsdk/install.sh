#!/bin/bash
# Check if running from installed package
if [ -d "/usr/lib/dexhandsdk" ]; then
  LIBS_DIR="/usr/lib"
else
  # Script is running from the source directory
  current_dir=$(pwd)
  LIBS_DIR="$current_dir/libs"
fi

# current_dir=$(pwd)
# parent_dir=$(dirname "$current_dir")
subdirs=("libs")

# 设置 libs 目录路径
LIBS_DIR="$current_dir/libs"

# Function to print system information
print_system_info() {
  echo "======================系统基本信息========================"
  echo "主机名: $(hostname)"
  echo "IP地址: $(hostname -I | cut -d' ' -f1)"
  echo "操作系统: $(cat /etc/os-release | grep PRETTY_NAME | cut -d= -f2 | tr -d '\"')"
  echo "内核版本: $(uname -r)"
  echo "启动时间: $(uptime -s)"
  echo "运行时长: $(uptime -p)"
  echo "系统负载: $(uptime | awk -F'load average:' '{print $2}')"
  echo "当前时间: $(date)"
}

# Function to append export command to bashrc
append_to_bashrc() {
    # 检查 libs 目录是否存在
    # 检查 ~/.bashrc 中是否已有设置
    if ! grep -q "export LD_LIBRARY_PATH=\"$LIBS_DIR:\$LD_LIBRARY_PATH\"" ~/.bashrc; then
        if [ -d "$LIBS_DIR" ]; then
            # 将libs目录修改写入 ~/.bashrc 文件
            echo "export LD_LIBRARY_PATH=\"$LIBS_DIR:\$LD_LIBRARY_PATH\"" >> ~/.bashrc
            echo "LD_LIBRARY_PATH write to your .bashrc."
        else
            echo "Error: 'libs' directory not found in the current directory!"
            exit 1
        fi
        echo "LD_LIBRARY_PATH will be updated in the future terminal sessions."
    else
        echo "LD_LIBRARY_PATH already exists in ~/.bashrc"
    fi

}

# Function to print current LD_LIBRARY_PATH
print_ld_library_path() {
    for subdir in "${subdirs[@]}"; do
        # 检查子文件夹是否存在
        echo libpathdir: $current_dir/$subdir
        if [ -d "$current_dir/$subdir" ]; then
            export LD_LIBRARY_PATH="$LD_LIBRARY_PATH:$current_dir/$subdir"
            # sudo ldconfig
        else
            echo "警告: 子文件夹 '$subdir' 不存在."
        fi
    done
}

# Function to install dependencies
install_dependencies() {
  sudo apt-get update && sudo apt-get install -y \
    build-essential cmake libboost-all-dev libopencv-dev \
    libspdlog-dev libfmt-dev libgoogle-glog-dev libopenblas-dev \
    libdlib-dev libjsoncpp-dev libfltk1.3-dev libyaml-cpp-dev vim python3-pip
  pip install pybind11
}

# Function to print help message
print_help() {
  echo "Usage: install.sh [OPTIONS]"
  echo "Options:"
  echo "  -help   Show this help message and exit"
  echo "  -libpath   Export LD_LIBRARY_PATH to ~/.bashrc"
}

# Function to compile GSL
compile_gsl() {
#   git clone https://github.com/ampl/gsl.git
  if [ ! -f "gsl.tar.gz" ]; then
    echo "警告: gsl.tar.gz 文件不存在，无法编译 GSL."
    return 1
  fi
  tar -xzf gsl.tar.gz && cd gsl
  ./configure CFLAGS="-g -O0" && make -j4
  sudo make install
  cd ..
}

# Function to compile Eigen3
compile_eigen3() {
#   wget https://gitlab.com/libeigen/eigen/-/archive/3.3.7/eigen-3.3.7.tar.gz --no-check-certificate
  if [ ! -f "eigen-3.3.7.tar.gz" ]; then
    echo "警告: eigen-3.3.7.tar.gz 文件不存在，无法编译 Eigen3."
    return 1
  fi
  tar -xzf eigen-3.3.7.tar.gz && cd eigen-3.3.7
  mkdir build && cd build
  cmake .. && sudo make install
  cd ../..
}

# Main script logic
print_system_info

append_to_bashrc
# Install dependencies
install_dependencies

# # Compile GSL and Eigen3
compile_gsl
compile_eigen3

# # Source SDK env
source ~/.bashrc
sudo ldconfig

# 输出最终的 LD_LIBRARY_PATH
echo "$LD_LIBRARY_PATH"

echo "All dependencies have been successfully installed."
