#----------------------------------------------------------------
# Generated CMake target import file.
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "cpp-ipc::ipc" for configuration ""
set_property(TARGET cpp-ipc::ipc APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(cpp-ipc::ipc PROPERTIES
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib/libipc.so.1.3.0"
  IMPORTED_SONAME_NOCONFIG "libipc.so.3"
  )

list(APPEND _IMPORT_CHECK_TARGETS cpp-ipc::ipc )
list(APPEND _IMPORT_CHECK_FILES_FOR_cpp-ipc::ipc "${_IMPORT_PREFIX}/lib/libipc.so.1.3.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
