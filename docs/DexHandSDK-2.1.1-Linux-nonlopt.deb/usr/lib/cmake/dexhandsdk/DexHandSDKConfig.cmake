
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was dexhandsdkConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

# Use set_and_check to verify that the directories actually exist
set_and_check(DEXHANDSDK_INCLUDE_DIRS "${PACKAGE_PREFIX_DIR}/include")
set_and_check(DEXHANDSDK_LIBRARY_DIRS "${PACKAGE_PREFIX_DIR}/lib")

# 查找所有 dexhandsdk 库文件
file(GLOB DEXHANDSDK_LIBS "${PACKAGE_PREFIX_DIR}/lib/libdexh*.so*")
set(DEXHANDSDK_ALL_LIBS "")
set(DEXHANDSDK_LIBS "${DEXHANDSDK_LIBS}")

foreach(lib ${DEXHANDSDK_LIBS})
  get_filename_component(libname ${lib} NAME_WE)
  string(REPLACE "lib" "" libname ${libname})
  list(APPEND DEXHANDSDK_ALL_LIBS ${libname})
  list(APPEND DEXHANDSDK_LIBS \${lib})
endforeach()

# 包含导出的目标
include("${CMAKE_CURRENT_LIST_DIR}/dexhandsdk-targets.cmake" OPTIONAL RESULT_VARIABLE _targets_found)

# 如果找不到目标文件，则创建导入的目标
if(NOT _targets_found)
  foreach(lib ${DEXHANDSDK_ALL_LIBS})
    if(NOT TARGET ${lib})
      add_library(${lib} SHARED IMPORTED)
      set_target_properties(${lib} PROPERTIES
        IMPORTED_LOCATION "${PACKAGE_PREFIX_DIR}/lib/lib${lib}.so"
        INTERFACE_INCLUDE_DIRECTORIES "${PACKAGE_PREFIX_DIR}/include"
      )
      add_library(dexhandsdk::${lib} ALIAS ${lib})
    endif()
  endforeach()
endif()

# Additional configuration variables if needed
# set(DEXHANDSDK_FOUND TRUE)

# 检查包是否完整
check_required_components(dexhandsdk)
